import { Body, Controller, Post } from '@nestjs/common';
import { AuthService } from './auth.service';
import { CreateExternadoUserDto } from 'src/externado_users/dto/create-externado_user.dto';

@Controller('auth')
export class AuthController {

    constructor(
        private readonly authService: AuthService
    ){}

    @Post("register")
    crearUsuario(@Body() createExternadoUserDto: CreateExternadoUserDto) {
        return this.authService.register(createExternadoUserDto);
    }

    @Post("login")
    login(@Body() createExternadoUserDto: CreateExternadoUserDto) {
        return this.authService.login(createExternadoUserDto);
    }
}
