import { Injectable } from '@nestjs/common';
import { CreateExternadoResponsibleDto } from './dto/create-externado_responsible.dto';
import { UpdateExternadoResponsibleDto } from './dto/update-externado_responsible.dto';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { ExternadoResponsible } from './entities/externado_responsible.entity';

@Injectable()
export class ExternadoResponsibleService {
  constructor(
    @InjectRepository(ExternadoResponsible)
    private readonly externadoResponsibleRepository: Repository<ExternadoResponsible>
  )
  {}
  
  async create(createExternadoResponsibleDto: CreateExternadoResponsibleDto) {
    return 'This action adds a new externadoResponsible';
  }

  async findAll() {
    return await this.externadoResponsibleRepository.find({
      relations: ["externadoUser", "externadoDepartment", "externadoRespType"],
  });
  }

  async findOne(idexternado_responsible: number) {
    return await this.externadoResponsibleRepository.findOneBy({idexternado_responsible});
  }

  async update(id: number, updateExternadoResponsibleDto: UpdateExternadoResponsibleDto) {
    return `This action updates a #${id} externadoResponsible`;
  }

  async remove(id: number) {
    return `This action removes a #${id} externadoResponsible`;
  }
}
