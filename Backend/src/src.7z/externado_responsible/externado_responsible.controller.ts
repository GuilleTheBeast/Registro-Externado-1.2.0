import { Controller, Get, Post, Body, Patch, Param, Delete } from '@nestjs/common';
import { ExternadoResponsibleService } from './externado_responsible.service';
import { CreateExternadoResponsibleDto } from './dto/create-externado_responsible.dto';
import { UpdateExternadoResponsibleDto } from './dto/update-externado_responsible.dto';

@Controller('externado-responsible')
export class ExternadoResponsibleController {
  constructor(private readonly externadoResponsibleService: ExternadoResponsibleService) {}

  @Post()
  create(@Body() createExternadoResponsibleDto: CreateExternadoResponsibleDto) {
    return this.externadoResponsibleService.create(createExternadoResponsibleDto);
  }

  @Get()
  findAll() {
    return this.externadoResponsibleService.findAll();
  }

  @Get(':id')
  findOne(@Param('id') id: string) {
    return this.externadoResponsibleService.findOne(+id);
  }

  @Patch(':id')
  update(@Param('id') id: string, @Body() updateExternadoResponsibleDto: UpdateExternadoResponsibleDto) {
    return this.externadoResponsibleService.update(+id, updateExternadoResponsibleDto);
  }

  @Delete(':id')
  remove(@Param('id') id: string) {
    return this.externadoResponsibleService.remove(+id);
  }
}
