import { Module } from '@nestjs/common';
import { ExternadoResponsibleService } from './externado_responsible.service';
import { ExternadoResponsibleController } from './externado_responsible.controller';
import { TypeOrmModule } from '@nestjs/typeorm';
import { ExternadoResponsible } from './entities/externado_responsible.entity';

@Module({
  imports: [TypeOrmModule.forFeature([ExternadoResponsible])],
  controllers: [ExternadoResponsibleController],
  providers: [ExternadoResponsibleService],
})
export class ExternadoResponsibleModule {}
