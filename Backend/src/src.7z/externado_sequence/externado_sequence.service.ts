import { Injectable } from '@nestjs/common';
import { UpdateExternadoSequenceDto } from './dto/update-externado_sequence.dto';
import { InjectRepository } from '@nestjs/typeorm';
import { ExternadoSequence } from './entities/externado_sequence.entity';
import { Repository } from 'typeorm';

@Injectable()
export class ExternadoSequenceService {
  constructor(
    @InjectRepository(ExternadoSequence)
    private readonly externadoSequenceRepository: Repository<ExternadoSequence>
  )
  {}

  async findAll() {
    return await this.externadoSequenceRepository.find();
  }

  async findOne(idexternado_sequence: number) {
  return await this.externadoSequenceRepository.findOneBy({idexternado_sequence});
  }

  async update(id: number, updateExternadoSequenceDto: UpdateExternadoSequenceDto) {
    return `This action updates a #${id} externadoSequence`;
  }

}
