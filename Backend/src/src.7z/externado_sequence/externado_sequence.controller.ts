import { Controller, Get, Body, Patch, Param } from '@nestjs/common';
import { ExternadoSequenceService } from './externado_sequence.service';
import { UpdateExternadoSequenceDto } from './dto/update-externado_sequence.dto';

@Controller('externado-sequence')
export class ExternadoSequenceController {
  constructor(private readonly externadoSequenceService: ExternadoSequenceService) {}

  @Get()
  findAll() {
    return this.externadoSequenceService.findAll();
  }

  @Get(':id')
  findOne(@Param('id') id: string) {
    return this.externadoSequenceService.findOne(+id);
  }

  @Patch(':id')
  update(@Param('id') id: string, @Body() updateExternadoSequenceDto: UpdateExternadoSequenceDto) {
    return this.externadoSequenceService.update(+id, updateExternadoSequenceDto);
  }

}
