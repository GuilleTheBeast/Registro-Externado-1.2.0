import { Controller, Get, Post, Body, Patch, Param, Delete } from '@nestjs/common';
import { ExternadoResponsibleTypeService } from './externado_responsible_type.service';
import { CreateExternadoResponsibleTypeDto } from './dto/create-externado_responsible_type.dto';
import { UpdateExternadoResponsibleTypeDto } from './dto/update-externado_responsible_type.dto';

@Controller('externado-responsible-type')
export class ExternadoResponsibleTypeController {
  constructor(private readonly externadoResponsibleTypeService: ExternadoResponsibleTypeService) {}

  @Post()
  create(@Body() createExternadoResponsibleTypeDto: CreateExternadoResponsibleTypeDto) {
    return this.externadoResponsibleTypeService.create(createExternadoResponsibleTypeDto);
  }

  @Get()
  findAll() {
    return this.externadoResponsibleTypeService.findAll();
  }

  @Get(':id')
  findOne(@Param('id') id: string) {
    return this.externadoResponsibleTypeService.findOne(+id);
  }

  @Patch(':id')
  update(@Param('id') id: string, @Body() updateExternadoResponsibleTypeDto: UpdateExternadoResponsibleTypeDto) {
    return this.externadoResponsibleTypeService.update(+id, updateExternadoResponsibleTypeDto);
  }

  @Delete(':id')
  remove(@Param('id') id: string) {
    return this.externadoResponsibleTypeService.remove(+id);
  }
}
