import { Module } from '@nestjs/common';
import { ExternadoResponsibleTypeService } from './externado_responsible_type.service';
import { ExternadoResponsibleTypeController } from './externado_responsible_type.controller';
import { TypeOrmModule } from '@nestjs/typeorm';
import { ExternadoResponsibleType } from './entities/externado_responsible_type.entity';

@Module({
  imports: [TypeOrmModule.forFeature([ExternadoResponsibleType])],
  controllers: [ExternadoResponsibleTypeController],
  providers: [ExternadoResponsibleTypeService],
})
export class ExternadoResponsibleTypeModule {}
