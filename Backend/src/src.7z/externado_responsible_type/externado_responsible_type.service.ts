import { Injectable } from '@nestjs/common';
import { CreateExternadoResponsibleTypeDto } from './dto/create-externado_responsible_type.dto';
import { UpdateExternadoResponsibleTypeDto } from './dto/update-externado_responsible_type.dto';
import { InjectRepository } from '@nestjs/typeorm';
import { ExternadoResponsibleType } from './entities/externado_responsible_type.entity';
import { Repository } from 'typeorm';

@Injectable()
export class ExternadoResponsibleTypeService {
  constructor(
    @InjectRepository(ExternadoResponsibleType)
    private readonly externadoResponsibleTypeRepository: Repository<ExternadoResponsibleType>
  )
  {}
  
  async create(createExternadoResponsibleTypeDto: CreateExternadoResponsibleTypeDto) {
    return 'This action adds a new externadoResponsibleType';
  }

  async findAll() {
    return await this.externadoResponsibleTypeRepository.find();
  }

  async findOne(idexternado_responsible_type: number) {
    return await this.externadoResponsibleTypeRepository.findOneBy({idexternado_responsible_type});
  }

  async update(id: number, updateExternadoResponsibleTypeDto: UpdateExternadoResponsibleTypeDto) {
    return `This action updates a #${id} externadoResponsibleType`;
  }

  async remove(id: number) {
    return `This action removes a #${id} externadoResponsibleType`;
  }
}
