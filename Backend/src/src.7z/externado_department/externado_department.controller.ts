import { Controller, Get, Post, Body, Patch, Param, Delete } from '@nestjs/common';
import { ExternadoDepartmentService } from './externado_department.service';
import { CreateExternadoDepartmentDto } from './dto/create-externado_department.dto';
import { UpdateExternadoDepartmentDto } from './dto/update-externado_department.dto';

@Controller('externado-department')
export class ExternadoDepartmentController {
  constructor(private readonly externadoDepartmentService: ExternadoDepartmentService) {}

  @Post()
  create(@Body() createExternadoDepartmentDto: CreateExternadoDepartmentDto) {
    return this.externadoDepartmentService.create(createExternadoDepartmentDto);
  }

  @Get()
  findAll() {
    return this.externadoDepartmentService.findAll();
  }

  @Get(':id')
  findOne(@Param('id') id: string) {
    return this.externadoDepartmentService.findOne(+id);
  }

  @Patch(':id')
  update(@Param('id') id: string, @Body() updateExternadoDepartmentDto: UpdateExternadoDepartmentDto) {
    return this.externadoDepartmentService.update(+id, updateExternadoDepartmentDto);
  }

  @Delete(':id')
  remove(@Param('id') id: string) {
    return this.externadoDepartmentService.remove(+id);
  }
}
