import { Injectable } from '@nestjs/common';
import { CreateExternadoDepartmentDto } from './dto/create-externado_department.dto';
import { UpdateExternadoDepartmentDto } from './dto/update-externado_department.dto';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { ExternadoDepartment } from './entities/externado_department.entity';

@Injectable()
export class ExternadoDepartmentService {
  constructor(
    @InjectRepository(ExternadoDepartment)
    private readonly externadoDepartmentRepository: Repository<ExternadoDepartment>
  )
  {}
  
  async create(createExternadoDepartmentDto: CreateExternadoDepartmentDto) {
    return 'This action adds a new externadoDepartment';
  }

  async findAll() {
    return await this.externadoDepartmentRepository.find();
  }

  async findOne(idexternado_departments: number) {
    return await this.externadoDepartmentRepository.findOneBy({idexternado_departments});
  }

  async update(id: number, updateExternadoDepartmentDto: UpdateExternadoDepartmentDto) {
    return `This action updates a #${id} externadoDepartment`;
  }

  async remove(id: number) {
    return `This action removes a #${id} externadoDepartment`;
  }
}
