import { Module } from '@nestjs/common';
import { ExternadoDepartmentService } from './externado_department.service';
import { ExternadoDepartmentController } from './externado_department.controller';
import { ExternadoDepartment } from './entities/externado_department.entity';
import { TypeOrmModule } from '@nestjs/typeorm';

@Module({
  imports: [TypeOrmModule.forFeature([ExternadoDepartment])],
  controllers: [ExternadoDepartmentController],
  providers: [ExternadoDepartmentService],
})
export class ExternadoDepartmentModule {}
