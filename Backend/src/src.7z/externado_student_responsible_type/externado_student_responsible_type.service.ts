import { Injectable } from '@nestjs/common';
import { CreateExternadoStudentResponsibleTypeDto } from './dto/create-externado_student_responsible_type.dto';
import { UpdateExternadoStudentResponsibleTypeDto } from './dto/update-externado_student_responsible_type.dto';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { ExternadoStudentResponsibleType } from './entities/externado_student_responsible_type.entity';

@Injectable()
export class ExternadoStudentResponsibleTypeService {
  constructor(
    @InjectRepository(ExternadoStudentResponsibleType)
    private readonly externadoStudentResponsibleTypeRepository: Repository<ExternadoStudentResponsibleType>
  )
  {}
  
  async create(createExternadoStudentResponsibleTypeDto: CreateExternadoStudentResponsibleTypeDto) {
    return 'This action adds a new externadoStudentResponsibleType';
  }

  async findAll() {
    return await this.externadoStudentResponsibleTypeRepository.find();
  }

  async findOne(idexternado_student_responsible_type: number) {
    return await this.externadoStudentResponsibleTypeRepository.findOneBy({idexternado_student_responsible_type});
  }

  async update(id: number, updateExternadoStudentResponsibleTypeDto: UpdateExternadoStudentResponsibleTypeDto) {
    return `This action updates a #${id} externadoStudentResponsibleType`;
  }

  async remove(id: number) {
    return `This action removes a #${id} externadoStudentResponsibleType`;
  }
}
