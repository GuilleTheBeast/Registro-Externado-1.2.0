import { Module } from '@nestjs/common';
import { ExternadoStudentResponsibleTypeService } from './externado_student_responsible_type.service';
import { ExternadoStudentResponsibleTypeController } from './externado_student_responsible_type.controller';
import { TypeOrmModule } from '@nestjs/typeorm';
import { ExternadoStudentResponsibleType } from './entities/externado_student_responsible_type.entity';

@Module({
  imports: [TypeOrmModule.forFeature([ExternadoStudentResponsibleType])],
  controllers: [ExternadoStudentResponsibleTypeController],
  providers: [ExternadoStudentResponsibleTypeService],
})
export class ExternadoStudentResponsibleTypeModule {}
