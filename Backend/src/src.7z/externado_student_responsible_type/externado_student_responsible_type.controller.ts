import { Controller, Get, Post, Body, Patch, Param, Delete } from '@nestjs/common';
import { ExternadoStudentResponsibleTypeService } from './externado_student_responsible_type.service';
import { CreateExternadoStudentResponsibleTypeDto } from './dto/create-externado_student_responsible_type.dto';
import { UpdateExternadoStudentResponsibleTypeDto } from './dto/update-externado_student_responsible_type.dto';

@Controller('externado-student-responsible-type')
export class ExternadoStudentResponsibleTypeController {
  constructor(private readonly externadoStudentResponsibleTypeService: ExternadoStudentResponsibleTypeService) {}

  @Post()
  create(@Body() createExternadoStudentResponsibleTypeDto: CreateExternadoStudentResponsibleTypeDto) {
    return this.externadoStudentResponsibleTypeService.create(createExternadoStudentResponsibleTypeDto);
  }

  @Get()
  findAll() {
    return this.externadoStudentResponsibleTypeService.findAll();
  }

  @Get(':id')
  findOne(@Param('id') id: string) {
    return this.externadoStudentResponsibleTypeService.findOne(+id);
  }

  @Patch(':id')
  update(@Param('id') id: string, @Body() updateExternadoStudentResponsibleTypeDto: UpdateExternadoStudentResponsibleTypeDto) {
    return this.externadoStudentResponsibleTypeService.update(+id, updateExternadoStudentResponsibleTypeDto);
  }

  @Delete(':id')
  remove(@Param('id') id: string) {
    return this.externadoStudentResponsibleTypeService.remove(+id);
  }
}
