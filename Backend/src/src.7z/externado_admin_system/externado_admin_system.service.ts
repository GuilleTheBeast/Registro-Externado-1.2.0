import { Injectable } from '@nestjs/common';
import { CreateExternadoAdminSystemDto } from './dto/create-externado_admin_system.dto';
import { UpdateExternadoAdminSystemDto } from './dto/update-externado_admin_system.dto';
import { InjectRepository } from '@nestjs/typeorm';
import { ExternadoAdminSystem } from './entities/externado_admin_system.entity';
import { Repository } from 'typeorm';

@Injectable()
export class ExternadoAdminSystemService {
  constructor(
    @InjectRepository(ExternadoAdminSystem)
    private readonly externadoAdminSystemRepository: Repository<ExternadoAdminSystem>
  )
  {}
  
  async create(createExternadoAdminSystemDto: CreateExternadoAdminSystemDto) {
    return 'This action adds a new externadoAdminSystem';
  }

  async findAll() {
    return await this.externadoAdminSystemRepository.find();
  }

  async findOne(idexternado_admin_system: number) {
    return await this.externadoAdminSystemRepository.findOneBy({idexternado_admin_system});
  }

  async update(id: number, updateExternadoAdminSystemDto: UpdateExternadoAdminSystemDto) {
    return `This action updates a #${id} externadoAdminSystem`;
  }

  async remove(id: number) {
    return `This action removes a #${id} externadoAdminSystem`;
  }
}
