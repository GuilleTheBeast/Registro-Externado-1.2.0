import { Controller, Get, Post, Body, Patch, Param, Delete } from '@nestjs/common';
import { ExternadoAdminSystemService } from './externado_admin_system.service';
import { CreateExternadoAdminSystemDto } from './dto/create-externado_admin_system.dto';
import { UpdateExternadoAdminSystemDto } from './dto/update-externado_admin_system.dto';

@Controller('externado-admin-system')
export class ExternadoAdminSystemController {
  constructor(private readonly externadoAdminSystemService: ExternadoAdminSystemService) {}

  @Post()
  create(@Body() createExternadoAdminSystemDto: CreateExternadoAdminSystemDto) {
    return this.externadoAdminSystemService.create(createExternadoAdminSystemDto);
  }

  @Get()
  findAll() {
    return this.externadoAdminSystemService.findAll();
  }

  @Get(':id')
  findOne(@Param('id') id: string) {
    return this.externadoAdminSystemService.findOne(+id);
  }

  @Patch(':id')
  update(@Param('id') id: string, @Body() updateExternadoAdminSystemDto: UpdateExternadoAdminSystemDto) {
    return this.externadoAdminSystemService.update(+id, updateExternadoAdminSystemDto);
  }

  @Delete(':id')
  remove(@Param('id') id: string) {
    return this.externadoAdminSystemService.remove(+id);
  }
}
