import { Module } from '@nestjs/common';
import { ExternadoAdminSystemService } from './externado_admin_system.service';
import { ExternadoAdminSystemController } from './externado_admin_system.controller';
import { TypeOrmModule } from '@nestjs/typeorm';
import { ExternadoAdminSystem } from './entities/externado_admin_system.entity';

@Module({
  imports: [TypeOrmModule.forFeature([ExternadoAdminSystem])],
  controllers: [ExternadoAdminSystemController],
  providers: [ExternadoAdminSystemService],
})
export class ExternadoAdminSystemModule {}
