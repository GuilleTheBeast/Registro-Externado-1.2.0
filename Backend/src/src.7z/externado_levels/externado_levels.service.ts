import { Injectable } from '@nestjs/common';
import { CreateExternadoLevelDto } from './dto/create-externado_level.dto';
import { UpdateExternadoLevelDto } from './dto/update-externado_level.dto';
import { InjectRepository } from '@nestjs/typeorm';
import { ExternadoLevel } from './entities/externado_level.entity';
import { Repository } from 'typeorm';


@Injectable()
export class ExternadoLevelsService {
  constructor(
    @InjectRepository(ExternadoLevel)
    private readonly externadoAdminRepository: Repository<ExternadoLevel>
  )
  {}

  async create(createExternadoLevelDto: CreateExternadoLevelDto) {
    return 'This action adds a new externadoLevel';
  }

  async findAll() {
    return await this.externadoAdminRepository.find();
  }

  async findOne(idexternado_level: number) {
    return await this.externadoAdminRepository.findOneBy({idexternado_level});
  }

  async update(id: number, updateExternadoLevelDto: UpdateExternadoLevelDto) {
    return `This action updates a #${id} externadoLevel`;
  }

  async remove(id: number) {
    return `This action removes a #${id} externadoLevel`;
  }
}
