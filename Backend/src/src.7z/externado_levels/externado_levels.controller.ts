import { Controller, Get, Post, Body, Patch, Param, Delete } from '@nestjs/common';
import { ExternadoLevelsService } from './externado_levels.service';
import { CreateExternadoLevelDto } from './dto/create-externado_level.dto';
import { UpdateExternadoLevelDto } from './dto/update-externado_level.dto';

@Controller('externado-levels')
export class ExternadoLevelsController {
  constructor(private readonly externadoLevelsService: ExternadoLevelsService) {}

  @Post()
  create(@Body() createExternadoLevelDto: CreateExternadoLevelDto) {
    return this.externadoLevelsService.create(createExternadoLevelDto);
  }

  @Get()
  findAll() {
    return this.externadoLevelsService.findAll();
  }

  @Get(':id')
  findOne(@Param('id') id: string) {
    return this.externadoLevelsService.findOne(+id);
  }

  @Patch(':id')
  update(@Param('id') id: string, @Body() updateExternadoLevelDto: UpdateExternadoLevelDto) {
    return this.externadoLevelsService.update(+id, updateExternadoLevelDto);
  }

  @Delete(':id')
  remove(@Param('id') id: string) {
    return this.externadoLevelsService.remove(+id);
  }
}
