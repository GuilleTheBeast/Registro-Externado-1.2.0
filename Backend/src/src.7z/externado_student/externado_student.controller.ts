import { Controller, Get, Post, Body, Patch, Param, Delete } from '@nestjs/common';
import { ExternadoStudentService } from './externado_student.service';
import { CreateExternadoStudentDto } from './dto/create-externado_student.dto';
import { UpdateExternadoStudentDto } from './dto/update-externado_student.dto';

@Controller('externado-student')
export class ExternadoStudentController {
  constructor(private readonly externadoStudentService: ExternadoStudentService) {}

  @Post()
  create(@Body() createExternadoStudentDto: CreateExternadoStudentDto) {
    return this.externadoStudentService.create(createExternadoStudentDto);
  }

  @Get()
  findAll() {
    return this.externadoStudentService.findAll();
  }

  @Get(':id')
  findOne(@Param('id') id: string) {
    return this.externadoStudentService.findOne(+id);
  }

  @Patch(':id')
  update(@Param('id') id: string, @Body() updateExternadoStudentDto: UpdateExternadoStudentDto) {
    return this.externadoStudentService.update(+id, updateExternadoStudentDto);
  }

  @Delete(':id')
  remove(@Param('id') id: string) {
    return this.externadoStudentService.remove(+id);
  }
}
