import { Injectable } from '@nestjs/common';
import { CreateExternadoStudentDto } from './dto/create-externado_student.dto';
import { UpdateExternadoStudentDto } from './dto/update-externado_student.dto';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { ExternadoStudent } from './entities/externado_student.entity';

@Injectable()
export class ExternadoStudentService {
  constructor(
    @InjectRepository(ExternadoStudent)
    private readonly externadoStudentRepository: Repository<ExternadoStudent>
  )
  {}
  
  async create(createExternadoStudentDto: CreateExternadoStudentDto) {
    return 'This action adds a new externadoStudent';
  }

  async findAll() {
    return await this.externadoStudentRepository.find({
      relations: ["externadoUser", "externadoDepartment", "externadoLevel", "externadoStudRespType"],
  });
  }

  async findOne(idexternado_student: number) {
    return await this.externadoStudentRepository.findOneBy({idexternado_student});
  }

  async update(id: number, updateExternadoStudentDto: UpdateExternadoStudentDto) {
    return `This action updates a #${id} externadoStudent`;
  }

  async remove(id: number) {
    return `This action removes a #${id} externadoStudent`;
  }
}
