import { Module } from '@nestjs/common';
import { ExternadoStudentService } from './externado_student.service';
import { ExternadoStudentController } from './externado_student.controller';
import { TypeOrmModule } from '@nestjs/typeorm';
import { ExternadoStudent } from './entities/externado_student.entity';

@Module({
  imports: [TypeOrmModule.forFeature([ExternadoStudent])],
  controllers: [ExternadoStudentController],
  providers: [ExternadoStudentService],
})
export class ExternadoStudentModule {}
