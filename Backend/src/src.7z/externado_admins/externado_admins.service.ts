import { Injectable } from '@nestjs/common';
import { CreateExternadoAdminDto } from './dto/create-externado_admin.dto';
import { UpdateExternadoAdminDto } from './dto/update-externado_admin.dto';
import { ExternadoAdmin } from './entities/externado_admin.entity';
import { Repository } from 'typeorm';
import { InjectRepository } from '@nestjs/typeorm';

@Injectable()
export class ExternadoAdminsService {
  constructor(
    @InjectRepository(ExternadoAdmin)
    private readonly externadoAdminRepository: Repository<ExternadoAdmin>
  )
  {}

  async create(createExternadoAdminDto: CreateExternadoAdminDto) {
    return 'This action adds a new externadoAdmin';
  }

  async findAll() {
    return await this.externadoAdminRepository.find({
      relations: ["externadoUser"],
  });
  }

  async findOne(idexternado_admin: number) {
    return await this.externadoAdminRepository.findOneBy({idexternado_admin});
  }

  async update(id: number, updateExternadoAdminDto: UpdateExternadoAdminDto) {
    return `This action updates a #${id} externadoAdmin`;
  }

  async remove(id: number) {
    return `This action removes a #${id} externadoAdmin`;
  }
}
