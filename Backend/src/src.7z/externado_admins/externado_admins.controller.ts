import { Controller, Get, Post, Body, Patch, Param, Delete } from '@nestjs/common';
import { ExternadoAdminsService } from './externado_admins.service';
import { CreateExternadoAdminDto } from './dto/create-externado_admin.dto';
import { UpdateExternadoAdminDto } from './dto/update-externado_admin.dto';

@Controller('externado-admins')
export class ExternadoAdminsController {
  constructor(private readonly externadoAdminsService: ExternadoAdminsService) {}

  @Post()
  create(@Body() createExternadoAdminDto: CreateExternadoAdminDto) {
    return this.externadoAdminsService.create(createExternadoAdminDto);
  }

  @Get()
  findAll() {
    return this.externadoAdminsService.findAll();
  }

  @Get(':id')
  findOne(@Param('id') id: number) {
    return this.externadoAdminsService.findOne(+id);
  }

  @Patch(':id')
  update(@Param('id') id: number, @Body() updateExternadoAdminDto: UpdateExternadoAdminDto) {
    return this.externadoAdminsService.update(+id, updateExternadoAdminDto);
  }

  @Delete(':id')
  remove(@Param('id') id: number) {
    return this.externadoAdminsService.remove(+id);
  }
}
