import { Module } from '@nestjs/common';
import { ExternadoAdminsService } from './externado_admins.service';
import { ExternadoAdminsController } from './externado_admins.controller';
import { ExternadoAdmin } from './entities/externado_admin.entity';
import { TypeOrmModule } from '@nestjs/typeorm';

@Module({
  imports: [TypeOrmModule.forFeature([ExternadoAdmin])],
  controllers: [ExternadoAdminsController],
  providers: [ExternadoAdminsService],
})
export class ExternadoAdminsModule {}
