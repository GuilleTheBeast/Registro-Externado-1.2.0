import { BadRequestException, Injectable, UnauthorizedException } from '@nestjs/common';
import { CreateExternadoUserDto } from './dto/create-externado_user.dto';
import { UpdateExternadoUserDto } from './dto/update-externado_user.dto';
import { InjectRepository } from '@nestjs/typeorm';
import { ExternadoUser } from './entities/externado_user.entity';
import { Repository } from 'typeorm';
import { ExternadoAdminSystem } from 'src/externado_admin_system/entities/externado_admin_system.entity';
import { ExternadoSequence } from 'src/externado_sequence/entities/externado_sequence.entity';
import { v5 as uuidv5 } from 'uuid';
import * as bcrypt from 'bcrypt';


@Injectable()
export class ExternadoUsersService {

  constructor(
    @InjectRepository(ExternadoUser)
    private readonly externadoUserRepository: Repository<ExternadoUser>,

    @InjectRepository(ExternadoAdminSystem)
    private readonly externadoAdminSystemRepository: Repository<ExternadoAdminSystem>, 

    @InjectRepository(ExternadoSequence)
    private readonly externadoSequenceRepository: Repository<ExternadoSequence>
  )
  {}

  async create(createExternadoUserDto: CreateExternadoUserDto) {
    const externado_email = createExternadoUserDto.externado_email;
    const externado_pass = createExternadoUserDto.externado_pass;
    const externado_generic_pass = createExternadoUserDto.externado_generic_pass;

    let message = "";

    try {
      
      const externadoAdminSystem = await this.externadoAdminSystemRepository.findOneBy({externado_generic_pass});

      if(externadoAdminSystem){//Verificamos si existe algun periodo con el token especificado

        if(externadoAdminSystem.externado_active_period){//Verificamos que el token del Externado sea de un periodo activo

          if (externadoAdminSystem.externado_system_closed){//Verificamos si el sistema esta activo o no para dicho periodo

            if(!await this.externadoUserRepository.findOneBy({externado_email})){//Verificamos que no exista ya un usuario con el mismo correo

              const sequences = await this.externadoSequenceRepository.findOneBy({idexternado_sequence: 1});//Traemos los registros de sequencias
              const idexternado_user_sequence = sequences.idexternado_user_sequence//Extraemos el valor de la sequencia para la tabla de usuarios

              const uuidValue = externado_email + "/0";
              const namespace = "1b671a64-40d5-491e-99b0-da01ff1f3341";
              const uuid = uuidv5(uuidValue, namespace);//Creamos un UUID a partir del correo ingresado


              const hashedPassword = await bcrypt.hash(externado_pass, 12);//Encriptamos la contraseña ingresada

              const idexternado_user = idexternado_user_sequence;

              //Asignamos los valores de control y contraseña encryptada
              createExternadoUserDto.idexternado_user = idexternado_user_sequence;
              createExternadoUserDto.externado_pass = hashedPassword;
              createExternadoUserDto.externado_uuid = uuid;

              this.externadoUserRepository.save(createExternadoUserDto);//Creamos el registro en la base de datos

              sequences.idexternado_user_sequence = (idexternado_user + 1);//Actualizamos la sequencia de usuarios incrementando en 1          
              await this.externadoSequenceRepository.save(sequences);//Actualizamos el registro de sequencias

              message = "Usuario creado con exito";

            }else{

              message = "Usuario ya existe";

            }
            
          }else{

            message = "El sistema esta inhabilitado para acceso";

          }
        }else{

          message = "El token es de un periodo expirado";

        }
      }else{

        message = "No existe dicho token especificado";

      }

    } catch (e) {

      message = e //TODO guardar en archivo log
      throw new BadRequestException(message);

    }
    return {

      message: message

    };
  }

  async login(createExternadoUserDto: CreateExternadoUserDto) {

    const externado_email = createExternadoUserDto.externado_email;
    const usuario = await this.externadoUserRepository.findOneBy({externado_email})//Realizamos la busqueda por medio del email

    let message = "";

    try {
      if(usuario){//Si se encontro un usuario existente, procedemos a comparar las contraseñas: la ingresada y la almacenada

        if(await bcrypt.compare(createExternadoUserDto.externado_pass, usuario.externado_pass)){
  
          message = "El usuario se ha logueado con exito"
  
        }else{
  
          message = "Credenciales Erroneas P"
          throw new UnauthorizedException();
  
        }
      }else{
  
        message = "Credenciales Erroneas U"
        throw new UnauthorizedException();
  
      }
    } catch (e) {
      message = e;
      throw new BadRequestException(message);
    }

    return {

      message: message

    };
  }

  async findAll() {
    return await this.externadoUserRepository.find();
  }

  async findOne(idexternado_user: number) {
    return await this.externadoUserRepository.findOneBy({idexternado_user});
  }


  async update(idexternado_user: number, updateExternadoUserDto: UpdateExternadoUserDto) {
    return await this.externadoUserRepository.update(idexternado_user, updateExternadoUserDto);
  }

  async remove(idexternado_user: number) {
    return `This action removes a #${idexternado_user} externadoUser`;
  }
}
