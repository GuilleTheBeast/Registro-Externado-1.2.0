import { PartialType } from '@nestjs/mapped-types';
import { CreateExternadoUserDto } from './create-externado_user.dto';
import { IsNumber, IsOptional, IsString, MaxLength } from 'class-validator';

export class UpdateExternadoUserDto extends PartialType(CreateExternadoUserDto) {
    
    @IsNumber()
    @IsOptional()
    idexternado_user: number;

    @IsString()
    @MaxLength(60)
    @IsOptional()
    externado_email: string;

    @IsString()
    @MaxLength(60)
    @IsOptional()
    externado_pass: string;

    @IsOptional()
    externado_user_type: boolean;

    @IsOptional()
    externado_active_user: boolean;

    @IsOptional()
    externado_reset_password: boolean;

    @IsString()
    @MaxLength(60)
    @IsOptional()
    externado_generic_pass: string;

    @IsString()
    @MaxLength(45)
    @IsOptional()
    externado_uuid: string;

}
