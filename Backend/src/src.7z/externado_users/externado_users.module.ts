import { Module } from '@nestjs/common';
import { ExternadoUsersService } from './externado_users.service';
import { ExternadoUsersController } from './externado_users.controller';
import { TypeOrmModule } from '@nestjs/typeorm';
import { ExternadoUser } from './entities/externado_user.entity';
import { ExternadoSequence } from 'src/externado_sequence/entities/externado_sequence.entity';
import { ExternadoAdminSystem } from 'src/externado_admin_system/entities/externado_admin_system.entity';

@Module({
  imports: [TypeOrmModule.forFeature([ExternadoUser, ExternadoAdminSystem, ExternadoSequence])],
  controllers: [ExternadoUsersController],
  providers: [ExternadoUsersService],
})
export class ExternadoUsersModule {}
