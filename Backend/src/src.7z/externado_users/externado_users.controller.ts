import { Controller, Get, Post, Body, Patch, Param, Delete } from '@nestjs/common';
import { ExternadoUsersService } from './externado_users.service';
import { CreateExternadoUserDto } from './dto/create-externado_user.dto';
import { UpdateExternadoUserDto } from './dto/update-externado_user.dto';

@Controller('externado-users')
export class ExternadoUsersController {
  constructor(
    private readonly externadoUsersService: ExternadoUsersService) {}

  @Post("crearUsuario")
  crearUsuario(@Body() createExternadoUserDto: CreateExternadoUserDto) {
    return this.externadoUsersService.create(createExternadoUserDto);
  }

  @Get("login")
  login(@Body() createExternadoUserDto: CreateExternadoUserDto) {
    return this.externadoUsersService.login(createExternadoUserDto);
  }

  @Get()
  findAll() {
    return this.externadoUsersService.findAll();
  }

  @Get(':id')
  findOne(@Param('id') id: number) {
    return this.externadoUsersService.findOne(id);
  }

  @Patch(':id')
  update(@Param('id') id: number, @Body() updateExternadoUserDto: UpdateExternadoUserDto) {
    return this.externadoUsersService.update(id, updateExternadoUserDto);
  }

  @Delete(':id')
  remove(@Param('id') id: number) {
    return this.externadoUsersService.remove(id);
  }
}
